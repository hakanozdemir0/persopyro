"""Yönetim komutları (management commands)."""
