"""accounts uygulamasının yönetim komutları."""
